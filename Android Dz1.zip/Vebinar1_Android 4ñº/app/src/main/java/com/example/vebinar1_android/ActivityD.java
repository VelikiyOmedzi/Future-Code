package com.example.vebinar1_android;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityD extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_d);
    }
}

