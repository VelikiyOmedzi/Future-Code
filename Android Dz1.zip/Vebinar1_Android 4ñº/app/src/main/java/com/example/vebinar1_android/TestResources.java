package com.example.vebinar1_android;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TestResources extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_resources);
        setTitle("Профиль пользователя @aleks");
    }
}